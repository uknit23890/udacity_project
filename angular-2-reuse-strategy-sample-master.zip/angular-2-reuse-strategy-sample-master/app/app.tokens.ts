import { OpaqueToken } from '@angular/core';

export const BASE_URL = new OpaqueToken('BASE_URL');
