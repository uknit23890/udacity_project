import { Component, OnInit } from '@angular/core';

@Component({
    template: '<h1>Chat!</h1>'
})
export class ChatComponent implements OnInit {
    constructor() {
    }

    ngOnInit() {
    }

}
