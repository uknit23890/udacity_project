import { expect } from 'chai';

describe('empty', () => {
  it('should work', () => {
    expect(true).to.be.true;
  });
});