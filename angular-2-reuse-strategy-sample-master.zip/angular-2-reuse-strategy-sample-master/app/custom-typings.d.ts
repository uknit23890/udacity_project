// to support require.context
interface NodeRequire {
    context: any;
}
