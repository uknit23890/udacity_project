/**
 * Created by parrikaa on 10/03/16.
 */
/***
 * CUSTOM DIRECTIVES MUST BE REGISTERED HERE INORDER TO USE THEM IN APPLICATION
 */
angular.module('customControlsModule', ['datePickerModule', 'sliderModule']);