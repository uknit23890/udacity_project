import { Component } from '@angular/core';
import { FlightService } from './services/flight.service';

@Component({
    selector: 'flight-booking',
    templateUrl: './flight-booking.component.html'
})
export class FlightBookingComponent {
}
